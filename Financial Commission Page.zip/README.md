
  # Financial Commission Page

  This is a code bundle for Financial Commission Page. The original project is available at https://www.figma.com/design/X1gdYdVbI3f4GbpJapCjAT/Financial-Commission-Page.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  